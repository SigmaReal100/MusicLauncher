package dev.musiclauncher.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class MusicLauncherScreen extends Screen {
    private int theme = 0;
    private final String[] themes = {"Тёмная", "Светлая", "Хэллоуин", "Новый год", "Весна", "Осень"};

    public MusicLauncherScreen() { super(Text.literal("Music Launcher")); }

    @Override
    protected void init() {
        int x = width / 2 - 100;
        int y = height / 2 - 55;
        addDrawableChild(ButtonWidget.builder(Text.literal("Тема: " + themes[theme]), b -> {
            theme = (theme + 1) % themes.length;
            b.setMessage(Text.literal("Тема: " + themes[theme]));
        }).dimensions(x, y, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Обои — позже"), b -> {}).dimensions(x, y + 26, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Косметика — позже"), b -> {}).dimensions(x, y + 52, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close()).dimensions(x, y + 78, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int color = switch (theme) {
            case 1 -> 0xFFEFEFEF;
            case 2 -> 0xFF301020;
            case 3 -> 0xFF17233A;
            case 4 -> 0xFF173522;
            case 5 -> 0xFF4A2F19;
            default -> 0xFF101522;
        };
        context.fill(0, 0, width, height, color);
        context.drawCenteredTextWithShadow(textRenderer, "MUSIC LAUNCHER", width / 2, height / 2 - 80, 0xFFFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() { return false; }
}
